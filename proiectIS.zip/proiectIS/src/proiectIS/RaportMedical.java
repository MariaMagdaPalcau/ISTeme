package proiectIS;

import java.time.LocalDate;
import java.util.ArrayList;

public class RaportMedical {
	private String IDUtilizator;
	private LocalDate data;
	private ArrayList<String> dateRaport;
	
	public RaportMedical(String iDUtilizator, LocalDate data, ArrayList<String> dateRaport) {
		this.IDUtilizator = iDUtilizator;
		this.data = data;
		this.dateRaport = dateRaport;
	}

	public String getIDUtilizator() {
		return IDUtilizator;
	}

	public void setIDUtilizator(String iDUtilizator) {
		IDUtilizator = iDUtilizator;
	}

	public LocalDate getData() {
		return data;
	}

	public void setData(LocalDate data) {
		this.data = data;
	}

	public ArrayList<String> getDateRaport() {
		return dateRaport;
	}

	public void setDateRaport(ArrayList<String> dateRaport) {
		this.dateRaport = dateRaport;
	}

	@Override
	public String toString() {
		return "RaportMedical [IDUtilizator=" + IDUtilizator + ", data=" + data + ", dateRaport=" + dateRaport + "]";
	}
}
