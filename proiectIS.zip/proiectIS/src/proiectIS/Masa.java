package proiectIS;

import java.time.LocalDate;
import java.util.ArrayList;

public class Masa {
	private String nume;
	private ArrayList<Aliment> alimente;
	private LocalDate data;
	
	public Masa(String n, LocalDate data) {
		this.nume = n;
		this.alimente = new ArrayList<>();
		this.data = data;
	}
	
	public String getNume() {
		return this.nume;
	}
	
	public ArrayList<Aliment> getAlimente(){
		return this.alimente;
	}
	
	public LocalDate getData() {
		return this.data;
	}

	public void setNume(String nume) {
		this.nume = nume;
	}

	public void setAlimente(ArrayList<Aliment> alimente) {
		this.alimente = alimente;
	}

	public void setData(LocalDate data) {
		this.data = data;
	}
	
	public void adaugaAliment(Aliment a) {
		alimente.add(a);
	}

	@Override
	public String toString() {
		return "[" + nume + ", alimente=" + alimente + ", data=" + data + "]";
	}
	
}
