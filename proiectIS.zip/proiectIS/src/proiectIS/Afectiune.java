package proiectIS;

public class Afectiune {
	private String IDUtilizator;
	private String nume;
	
	public Afectiune(String iDUtilizator, String nume) {
		this.IDUtilizator = iDUtilizator;
		this.nume = nume;
	}

	public String getIDUtilizator() {
		return IDUtilizator;
	}

	public void setIDUtilizator(String iDUtilizator) {
		IDUtilizator = iDUtilizator;
	}

	public String getNume() {
		return nume;
	}

	public void setNume(String nume) {
		this.nume = nume;
	}

	@Override
	public String toString() {
		return "Afectiune [IDUtilizator=" + IDUtilizator + ", nume=" + nume + "]";
	}
	
	
}
