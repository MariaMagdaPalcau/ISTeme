package proiectIS;

import java.util.ArrayList;

public class Utilizator {
	private String ID;
	private String nume;
	private String email;
	private String parola;
	private double greutate;
	private double inaltime;
	private ArrayList<RaportMedical> rapoarteMedicale;
	private ArrayList<Masa> mese;
	private ArrayList<Afectiune> afectiuni;
	
	Utilizator(String iD, String nume, String email, String parola, double greutate, double inaltime) {
		this.ID = iD;
		this.nume = nume;
		this.email = email;
		this.parola = parola;
		this.greutate = greutate;
		this.inaltime = inaltime;
		this.rapoarteMedicale = new ArrayList<>();
		this.mese = new ArrayList<>();
		this.afectiuni = new ArrayList<>();
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getNume() {
		return nume;
	}

	public void setNume(String nume) {
		this.nume = nume;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getParola() {
		return parola;
	}

	public void setParola(String parola) {
		this.parola = parola;
	}

	public double getGreutate() {
		return greutate;
	}

	public void setGreutate(double greutate) {
		this.greutate = greutate;
	}

	public double getInaltime() {
		return inaltime;
	}

	public void setInaltime(double inaltime) {
		this.inaltime = inaltime;
	}

	public ArrayList<RaportMedical> getRapoarteMedicale() {
		return rapoarteMedicale;
	}

	public void setRapoarteMedicale(ArrayList<RaportMedical> rapoarteMedicale) {
		this.rapoarteMedicale = rapoarteMedicale;
	}

	public ArrayList<Masa> getMese() {
		return mese;
	}

	public void setMese(ArrayList<Masa> mese) {
		this.mese = mese;
	}

	public ArrayList<Afectiune> getAfectiuni() {
		return afectiuni;
	}

	public void setAfectiuni(ArrayList<Afectiune> afectiuni) {
		this.afectiuni = afectiuni;
	}

	@Override
	public String toString() {
		return "Utilizator cu ID=" + ID + ", nume=" + nume + ", email=" + email + ", parola=" + parola + "\n greutate="
				+ greutate + "kg, inaltime=" + inaltime + "m\n rapoarteMedicale=" + rapoarteMedicale + "\nmese=" + mese
				+ "\n afectiuni=" + afectiuni;
	}
	
	public boolean login(String email, String parola) {
		return this.email.equals(email) && this.parola.equals(parola);
	}
	
	public void adaugaMasa(Masa m) {
		mese.add(m);
		System.out.println("A fost adaugata cu succes masa!");
	}
	
	public void introduceRaport(RaportMedical r) {
		rapoarteMedicale.add(r);
	}
	
	public void introduceAfectiune(Afectiune a) {
		afectiuni.add(a);
	}
	
	public void cerereSuport() {
		System.out.println("Cerere de suport trimisa catre nutritionist.");
	}
}
