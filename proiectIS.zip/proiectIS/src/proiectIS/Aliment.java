package proiectIS;

public class Aliment {
	private String nume;
	private double cantitate;
	
	public Aliment(String nume, double cantitate) {
		this.nume = nume;
		this.cantitate = cantitate;
	}

	public String getNume() {
		return nume;
	}

	public void setNume(String nume) {
		this.nume = nume;
	}

	public double getCantitate() {
		return cantitate;
	}

	public void setCantitate(double cantitate) {
		this.cantitate = cantitate;
	}

	@Override
	public String toString() {
		return nume + ": " + cantitate;
	}
}
