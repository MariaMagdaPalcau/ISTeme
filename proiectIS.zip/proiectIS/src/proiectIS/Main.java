package proiectIS;

import java.time.LocalDate;

public class Main {
	public static void main(String[] args) {
		Utilizator u = new Utilizator("u1", "Alex", "alex@gmail.com", "pass123", 80, 1.80);
		Aliment a1 = new Aliment("Pui", 200.0);
		Aliment a2 = new Aliment("Cartofi", 150.5);
		Aliment a3 = new Aliment("Salata", 170.2);
		LocalDate data = LocalDate.now();
		Masa m = new Masa("pranz", data);
		Masa m2 = new Masa("cina", data);
		m.adaugaAliment(a1);
		m.adaugaAliment(a2);
		m.adaugaAliment(a3);
		m2.adaugaAliment(a3);
		u.adaugaMasa(m);
		u.adaugaMasa(m2);
		System.out.println(u);
	}
}
